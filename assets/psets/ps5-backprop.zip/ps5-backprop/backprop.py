import warnings

import numpy as np
import matplotlib.pyplot as plt


def main() -> None:
    warnings.filterwarnings("ignore", category=RuntimeWarning, message=".*matmul.*")
    rng = np.random.default_rng(42)

    # We will randomly sample 256 training points on [-2, 2]:
    n = 256
    x = rng.uniform(-2.0, 2.0, size=(n, 1))

    # The polynomial we are fitting is: y = x^3 -2x^2 + x + 5
    a3, a2, a1, a0 = 1, -2, 1, 5
    y = a3 * x**3 + a2 * x**2 + a1 * x + a0

    # Model: a single hidden layer with 32 nodes and a ReLU activation function
    # These are the weights and biases you will need to train:
    hidden_dim = 32 # hidden dimension
    W1 = rng.normal(scale=0.2, size=(1, hidden_dim)) # 1x32 matrix (input to hidden layer)
    b1 = np.zeros((1, hidden_dim)) # 1x32 bias vector
    W2 = rng.normal(scale=0.2, size=(hidden_dim, 1)) # 32x1 matrix (hidden layer to output)
    b2 = np.zeros((1, 1)) # 1x1 bias vector

    def mlp_predict(x_in: np.ndarray, W1: np.ndarray, b1: np.ndarray, W2: np.ndarray, b2: np.ndarray) -> np.ndarray:
        z1 = np.matmul(x_in, W1) + b1
        h1 = np.maximum(0.0, z1)
        return np.matmul(h1, W2) + b2

    init_params = (W1.copy(), b1.copy(), W2.copy(), b2.copy())
    checkpoint_params: dict[int, tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = {}
    checkpoint_steps = (20, 200, 2000)

    lr = 0.05 # learning rate
    steps = 2000 # number of training steps

    losses = []
    for t in range(steps):
        ### YOUR CODE HERE ### 
        # Compute a single forward pass through the model:
        # - We can run the model on all of our data in a single batch (i.e., no for loop)
        # - You may find the mlp_predict function to be a helpful reference point
        # - However, you should not use this function directly because you will need to store 
        #   the intermediate activations for the backward pass
        # - We recommend using mean squared error because it will be easy to differentiate

        # Mean squared error (update this based on your forward pass above): 
        loss = 1000000
        ### END CODE HERE ###
        losses.append(float(loss))

        ### YOUR CODE HERE ### 
        # Compute a backward pass through the model:
        # - You should compute gradients for W1, b1, W2, b2 and then apply gradient descent updates
        # - You may find it helpful to compute gradients in the following order:
        #   dL/dyhat -> dL/dW2, dL/db2, dL/dh1 -> dL/dz1 -> dL/dW1, dL/db1
        # - You should use the chain rule to compute the gradients
        # - You will need to re-use the intermediate activations from the forward pass
        

        # Compute updates: 
        # W1 = ?? 
        # b1 = ?? 
        # W2 = ?? 
        # b2 = ?? 

        ### END CODE HERE ###

        if (t + 1) in checkpoint_steps:
            checkpoint_params[t + 1] = (W1.copy(), b1.copy(), W2.copy(), b2.copy())

        if (t + 1) % 200 == 0:
            print(f"step {t+1:4d}  loss {loss:.6f}")

    print(f"initial loss: {losses[0]:.6f}")
    print(f"final loss:   {losses[-1]:.6f}")

    cmap = plt.colormaps["Blues"]
    step_list = list(checkpoint_steps)
    colors = [cmap(v) for v in np.linspace(0.45, 0.9, num=len(step_list))]

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    def plot_fit(ax: plt.Axes, x_min: float, x_max: float, title: str) -> None:
        x_plot = np.linspace(x_min, x_max, 600).reshape(-1, 1)
        y_true = a3 * x_plot**3 + a2 * x_plot**2 + a1 * x_plot + a0
        ax.plot(
            x_plot,
            y_true,
            label="true polynomial",
            linewidth=2.75,
            color="tab:red",
            zorder=0,
        )

        y_uninit = mlp_predict(x_plot, *init_params)
        ax.plot(
            x_plot,
            y_uninit,
            label="model (uninitialized)",
            linestyle="--",
            alpha=0.5,
            color="0.7",
            zorder=2,
        )

        for k, col in zip(step_list, colors):
            if k in checkpoint_params:
                yk = mlp_predict(x_plot, *checkpoint_params[k])
                ax.plot(x_plot, yk, label=f"model ({k} steps)", alpha=0.5, color=col, zorder=3)

        ax.set_title(title)
        ax.set_xlabel("x")
        ax.set_ylabel("y")

    plot_fit(axes[0], -2.0, 2.0, "Fit on [-2, 2]")
    plot_fit(axes[1], -10.0, 10.0, "Fit on [-10, 10]")

    axes[2].plot(np.arange(1, steps + 1), losses, color="tab:red", linewidth=1.75)
    axes[2].set_title("Training loss (MSE)")
    axes[2].set_xlabel("step")
    axes[2].set_ylabel("loss")

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncols=3, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.88))
    plt.show()


if __name__ == "__main__":
    main()

