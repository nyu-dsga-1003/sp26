import os
import sys
import numpy as np
import random
from collections import Counter

def folder_list(path,label):
    '''
    PARAMETER PATH IS THE PATH OF YOUR LOCAL FOLDER
    '''
    filelist = os.listdir(path)
    review = []
    for infile in filelist:
        file = os.path.join(path,infile)
        r = read_data(file)
        r.append(label)
        review.append(r)
    return review

def read_data(file):
    '''
    Read each file into a list of strings.
    Example:
    ["it's", 'a', 'curious', 'thing', "i've", 'found', 'that', 'when', 'willis', 'is', 'not', 'called', 'on',
    ...'to', 'carry', 'the', 'whole', 'movie', "he's", 'much', 'better', 'and', 'so', 'is', 'the', 'movie']
    '''
    f = open(file)
    lines = f.read().split(' ')
    symbols = '${}()[].,:;+-*/&|<>=~" '
    words = map(lambda Element: Element.translate(str.maketrans("", "", symbols)).strip(), lines)
    words = filter(None, words)
    return list(words)


def load_and_shuffle_data():
    '''
    pos_path is where you save positive review data.
    neg_path is where you save negative review data.
    '''
    pos_path = "data_reviews/pos"
    neg_path = "data_reviews/neg"

    pos_review = folder_list(pos_path,1)
    neg_review = folder_list(neg_path,-1)

    review = pos_review + neg_review
    random.shuffle(review)
    return review

# Taken from http://web.stanford.edu/class/cs221/ Assignment #2 Support Code
def dotProduct(d1, d2):
    """
    @param dict d1: a feature vector represented by a mapping from a feature (string) to a weight (float).
    @param dict d2: same as d1
    @return float: the dot product between d1 and d2
    """
    if len(d1) < len(d2):
        return dotProduct(d2, d1)
    else:
        return sum(d1.get(f, 0) * v for f, v in d2.items())

def increment(d1, scale, d2):
    """
    Implements d1 += scale * d2 for sparse vectors.
    @param dict d1: the feature vector which is mutated.
    @param float scale
    @param dict d2: a feature vector.

    NOTE: This function does not return anything, but rather
    increments d1 in place. We do this because it is much faster to
    change elements of d1 in place than to build a new dictionary and
    return it.
    """
    for f, v in d2.items():
        d1[f] = d1.get(f, 0) + v * scale

class reviewInstance:
    """ Build the review class """
    def __init__(self,word_list):
        self.word_list = word_list[:-1]
        self.label = word_list[-1]
        self.word_dict = Counter()
        self.construct_word_dict()

    def construct_word_dict(self, stop_word=None, count_words=None):
        """
        count the words in word_list, transform to a dict of (word: word_count)
        :param stop_word: a list of stop words, The words you hope to filter, not
    included in dict, default set to None
        :param count_words: a list, the words you hope to keep in the count_dict, if
     set to None, will keep all the words
        :return:
        """
        c = Counter()
        c = Counter(self.word_list)
        if count_words:
            c = Counter({i: c[i] for i in count_words})
        if stop_word:
            for i in stop_word:
                del c[i]
        self.word_dict = c

###### YOUR CODE STARTS HERE ######

def pegasos_sgd_loss(review_X, review_y, w, reg_lambda):
    '''
    Args:
        review_X : dict of (word: word_count) for a review
        review_y : label of the review, either 1 or -1
        w : dict of (word: weight) for the SVM
        reg_lambda : regularization parameter

    Returns:
        loss: scalar value of objective function
    '''

def pegasos_sgd_gradient(review_X, review_y, w, reg_lambda):
    '''
    Args:
        review_X : dict of (word: word_count) for a review
        review_y : label of the review, either 1 or -1
        w : dict of (word: weight) for the SVM
        reg_lambda : regularization parameter
        
    Returns:
        gradient: dict of (word: gradient) for the SVM
    '''

def gradient_checker_for_pegasos(review_X, review_y, weight, reg_lambda,
                                 objective_func=pegasos_sgd_loss,
                                 gradient_func=pegasos_sgd_gradient, epsilon=0.01, tolerance=1e-4):

    true_gradient = gradient_func(review_X, review_y, weight, reg_lambda)
    weight_to_check = weight.copy()
    #To make weight to check have all the words appear in w and review stored in dict
    increment(weight_to_check, 0, review_X)
    approx_grad = weight_to_check.copy()

    for word in weight_to_check:
        weight_plus = weight_to_check.copy()
        weight_plus[word] += epsilon
        loss_plus = objective_func(review_X,review_y, weight_plus, reg_lambda)

        weight_minus = weight_to_check.copy()
        weight_minus[word] -= epsilon
        loss_minus = objective_func(review_X,review_y, weight_minus, reg_lambda)

        approx_grad[word] = (loss_plus - loss_minus)/(2*epsilon)
        #print word, weight_plus[word], weight_minus[word], loss_plus, loss_minus, approx_grad[word], true_gradient[word]

    distance = np.sum([(true_gradient[i] - approx_grad[i])**2 for i in approx_grad])
    return distance < tolerance

def pegasos(review_list, max_epoch, lam, watch_list=None, grad_checking=False):
    '''
    Args:
        review_list: list of reviewInstance
        max_epoch: maximum number of epochs to train
        lam: regularization parameter
        watch_list: list of reviewInstance to evaluate the loss after each epoch, default set to None (this will be used for validation set)
        grad_checking: boolean, whether to perform gradient checking, default set to False

    Returns:
        w: dict of (word: weight) for the SVM
    '''

def pegasos_fast(review_list, max_epoch, lam, watch_list=None):
    '''
    Args:
        review_list: list of reviewInstance
        max_epoch: maximum number of epochs to train
        lam: regularization parameter
        watch_list: list of reviewInstance to evaluate the loss after each epoch, default set to None (this will be used for validation set)

    Returns:
        w: dict of (word: weight) for the SVM
    '''

def svm_predict(review_X, weight):
    '''
    Args:
        review_X : dict of (word: word_count) for a review
        weight : dict of (word: weight) for the SVM
    Returns:
        label: either 1 or -1
    '''

def classification_error(review_list, weight):
    '''
    Args:
        review_list: list of reviewInstance
        weight: dict of (word: weight) for the SVM

    Returns:
        error: scalar value of classification error (0-1 loss on the review_list)
    '''

def main():
    print ("Loading data")
    review_list= load_and_shuffle_data()

    print ("Train validation split")
    train_review = list(map(reviewInstance,review_list[:1500]))
    validate_review = list(map(reviewInstance,review_list[1500:]))
    train_label = np.array([i.label for i in train_review])
    validate_label = np.array([i.label for i in validate_review])

    print ("In training: %r positive, %r negative" %(np.sum(train_label[train_label>0]), -np.sum(train_label[train_label<0])))
    print ("In validation: %r positive, %r negative" %(np.sum(validate_label[validate_label>0]), -np.sum(validate_label[validate_label<0])))

main()